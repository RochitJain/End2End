import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userup',
  templateUrl: './userup.component.html',
  styleUrls: ['./userup.component.css']
})
export class UserupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
