import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminlistmentor',
  templateUrl: './adminlistmentor.component.html',
  styleUrls: ['./adminlistmentor.component.css']
})
export class AdminlistmentorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
