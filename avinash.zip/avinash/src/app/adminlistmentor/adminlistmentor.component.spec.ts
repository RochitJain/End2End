import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminlistmentorComponent } from './adminlistmentor.component';

describe('AdminlistmentorComponent', () => {
  let component: AdminlistmentorComponent;
  let fixture: ComponentFixture<AdminlistmentorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminlistmentorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminlistmentorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
