import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminlistuserrComponent } from './adminlistuserr.component';

describe('AdminlistuserrComponent', () => {
  let component: AdminlistuserrComponent;
  let fixture: ComponentFixture<AdminlistuserrComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminlistuserrComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminlistuserrComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
