import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminlistuserr',
  templateUrl: './adminlistuserr.component.html',
  styleUrls: ['./adminlistuserr.component.css']
})
export class AdminlistuserrComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
