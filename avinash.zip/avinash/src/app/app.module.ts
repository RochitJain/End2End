import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserinComponent } from './userin/userin.component';
import { UserupComponent } from './userup/userup.component';

import { componentFactoryName } from '@angular/compiler';
import { MainComponent } from './main/main.component';
import { MentorinComponent } from './mentorin/mentorin.component';
import { MentorupComponent } from './mentorup/mentorup.component';
import { AdminComponent } from './admin/admin.component';
import { SuccessComponent } from './success/success.component';
import { AdminlistComponent } from './adminlist/adminlist.component';
import { UserhistoryComponent } from './userhistory/userhistory.component';
import { ApaymentComponent } from './apayment/apayment.component';
import { AdminpaymentComponent } from './adminpayment/adminpayment.component';
import { MpaymentpendingComponent } from './mpaymentpending/mpaymentpending.component';
import { SearchComponent } from './search/search.component';
import { MentorhistoryComponent } from './mentorhistory/mentorhistory.component';
import { AdminlistmentorComponent } from './adminlistmentor/adminlistmentor.component';
import { AdminlistuserComponent } from './adminlistuser/adminlistuser.component';
import { AdminlistuserrComponent } from './adminlistuserr/adminlistuserr.component';

@NgModule({
  declarations: [
    AppComponent,
    UserinComponent,
    UserupComponent,
    MainComponent,
    MentorinComponent,
    MentorupComponent,
    AdminComponent,
    SuccessComponent,
    AdminlistComponent,
    UserhistoryComponent,
    ApaymentComponent,
    AdminpaymentComponent,
    MpaymentpendingComponent,
    SearchComponent,
    MentorhistoryComponent,
    AdminlistmentorComponent,
    AdminlistuserComponent,
    AdminlistuserrComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot([
      {
        path: 'userin',
        component: UserinComponent
      },
      {
        path: 'userup',
        component: UserupComponent
      },

      {
        path: '',
        component: MainComponent
      },
      {
        path: 'mentorin',
        component: MentorinComponent
      },
      {
        path: 'mentorup',
        component: MentorupComponent
      },
      {
        path: 'admin',
        component: AdminComponent
      }, 
      {
        path: 'alist',
        component: AdminlistComponent
      }, 
        //   {
      //     path: '',
      //   pathMatch: 'full',
      //   redirectTo: 'userup'

      // }
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
