import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userin',
  templateUrl: './userin.component.html',
  styleUrls: ['./userin.component.css']
})
export class UserinComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
