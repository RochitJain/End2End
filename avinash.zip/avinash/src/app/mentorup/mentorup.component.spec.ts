import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentorupComponent } from './mentorup.component';

describe('MentorupComponent', () => {
  let component: MentorupComponent;
  let fixture: ComponentFixture<MentorupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentorupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentorupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
