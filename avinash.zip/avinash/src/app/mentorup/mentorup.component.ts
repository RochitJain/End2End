import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentorup',
  templateUrl: './mentorup.component.html',
  styleUrls: ['./mentorup.component.css']
})
export class MentorupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
