import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mpaymentpending',
  templateUrl: './mpaymentpending.component.html',
  styleUrls: ['./mpaymentpending.component.css']
})
export class MpaymentpendingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
