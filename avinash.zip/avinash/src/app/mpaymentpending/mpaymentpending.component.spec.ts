import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MpaymentpendingComponent } from './mpaymentpending.component';

describe('MpaymentpendingComponent', () => {
  let component: MpaymentpendingComponent;
  let fixture: ComponentFixture<MpaymentpendingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MpaymentpendingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MpaymentpendingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
