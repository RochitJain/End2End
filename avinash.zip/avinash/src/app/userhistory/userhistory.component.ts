import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userhistory',
  templateUrl: './userhistory.component.html',
  styleUrls: ['./userhistory.component.css']
})
export class UserhistoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
