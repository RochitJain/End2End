import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentorhistoryComponent } from './mentorhistory.component';

describe('MentorhistoryComponent', () => {
  let component: MentorhistoryComponent;
  let fixture: ComponentFixture<MentorhistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentorhistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentorhistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
