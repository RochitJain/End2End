import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentorhistory',
  templateUrl: './mentorhistory.component.html',
  styleUrls: ['./mentorhistory.component.css']
})
export class MentorhistoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
