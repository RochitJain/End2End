import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminpayment',
  templateUrl: './adminpayment.component.html',
  styleUrls: ['./adminpayment.component.css']
})
export class AdminpaymentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
