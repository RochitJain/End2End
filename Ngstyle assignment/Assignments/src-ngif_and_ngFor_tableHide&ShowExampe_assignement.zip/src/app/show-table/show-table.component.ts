import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-table',
  templateUrl: './show-table.component.html',
  styleUrls: ['./show-table.component.css']
})
export class ShowTableComponent implements OnInit {
      visibility: any =
      [
         {state : 'on'}
      ];
     tableData: any = [
       {name:'Manikandan.J',height: 178,visibility: 'off'},
       {name:'RamRajan',height: 180,visibility: 'off'},
       {name:'VictorSam',height: 187,visibility: 'off'},
       {name:'Will Courter',height: 167,visibility: 'off'}
     ];

     visible: boolean = false;
  constructor() { }

  ngOnInit() {
  }
  showTable()
  {
    this.visible = true;
  }

}
