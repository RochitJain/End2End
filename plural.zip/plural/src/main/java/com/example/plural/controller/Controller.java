package com.example.plural.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.plural.model.EntityClass;
import com.example.plural.repository.Repository;

@RestController
@RequestMapping("/home")
public class Controller {

	@Autowired
	private Repository repo;
	
	@GetMapping
	public List<EntityClass> getAll() {
		return repo.findAll();
	}
	
	@GetMapping("/{id}")
	public EntityClass findOne(@PathVariable int id) {
		return repo.getOne(id);
	}
	@PostMapping
	@ResponseStatus(HttpStatus.OK)
	public void save(@RequestBody EntityClass entityClass) {
		repo.save(entityClass);
	}
}
