package com.example.plural.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.plural.model.EntityClass;

public interface Repository extends JpaRepository<EntityClass, Integer> {

}
