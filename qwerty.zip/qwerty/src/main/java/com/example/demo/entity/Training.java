package com.example.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import org.springframework.lang.NonNull;

@Entity
@Table(name = "trainings_table")
public class Training {

	
	
		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
			private int id;
	 
		@NonNull
	   @Column(name = "user_id") 
	  private int user_id;
	  
	  @NonNull
	  @Column(name = "mentor_id")
	  private int mentor_id;
	  
	  @NonNull
	  @Column(name = "skill_id")
	  private String skill_id;
	  
	  @NonNull
	  @Column(name = "status")
	  private String status;
	  
	  @NonNull
	  @Column(name = "progress")
	  private String progress;
	  
	  @NonNull
	  @Column(name = "rating")
	  private int rating;
	  
	  @NonNull
	  @Column(name = "start_date")
	  private String start_date;
	  
	  @NonNull
	  @Column(name = "end_date")
	  private String end_date;
	  
	  @NonNull
	  @Column(name = "amount_received") 
	  private int amount_received;
	  
	  public Training() {
		  super();
		  }
	  
	  public Training(int id, int user_id, int mentor_id, String skill_id, String
	  status, String progress, int rating, String start_date, String end_date,
	  String maybe_start_time, String end_time, int amount_received)
	  { 
		  super();
		 this.id = id;
	  this.user_id = user_id;
	  this.mentor_id = mentor_id;
	  this.skill_id = skill_id;
	  this.status = status; 
	  this.progress = progress;
	  this.rating = rating;
	  this.start_date = start_date; 
	  this.end_date = end_date;
	  this.amount_received = amount_received;
	  }
	  
	 public long getId() { return id; } 
	  
	  public int getUser_id() { return user_id; }
	  
	  public int getMentor_id() { return mentor_id; }
	  
	  public String getSkill_id() { return skill_id; }
	  
	  public String getStatus() { return status; }
	  
	  public String getProgress() { return progress; }
	  
	  public int getRating() { return rating; }
	  
	  public String getStart_date() { return start_date; }
	  
	  public String getEnd_date() { return end_date; }
	  
	  
	  public int getAmount_received() { return amount_received; }
	  
	
	 public void setId(int id) { this.id = id; }
	  
	  public void setUser_id( int user_id) { this.user_id = user_id; }
	  
	  public void setMentor_id(int mentor_id) { this.mentor_id = mentor_id; }
	  
	  public void setSkill_id(String skill_id) { this.skill_id = skill_id; }
	  
	  public void setStatus(String status) { this.status = status; }
	  
	  public void setProgress(String progress) { this.progress = progress; }
	  
	  public void setRating(int rating) { this.rating = rating; }
	  
	  public void setStart_date(String start_date) { this.start_date = start_date;
	  }
	  
	  public void setEnd_date(String end_date) { this.end_date = end_date; }
	  

	  public void setAmount_received(int amount_received) { this.amount_received =
	  amount_received; }
	  
	  @Override public String toString() { return "TrainingsTable [id=" + id +
	  ", user_id=" + user_id + ", mentor_id=" + mentor_id + ", skill_id=" +
	  skill_id + ", status=" + status + ", progress=" + progress + ", rating=" +
	  rating + ", start_date=" + start_date + ", end_date=" + end_date +
	  ", amount_received=" + amount_received + "]"; }
	 
			
	}



