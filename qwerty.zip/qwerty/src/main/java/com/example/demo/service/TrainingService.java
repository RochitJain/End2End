package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Training;
import com.example.demo.repository.TrainingRepo;



@Service
@Transactional
public class TrainingService {

	@Autowired
	TrainingRepo trainnn;
	
	public List<Training>getAllTrain(){
		List<Training> tt=new ArrayList<Training>();
		for(Training t:trainnn.findAll())
		{
			tt.add(t);
		}
		return tt;
	}
	
	public TrainingService(TrainingRepo train) {
		this.trainnn=train;
	}
	public void saveAllTrainee(Training trainee) {
		trainnn.save(trainee);
	}

	private void TrainingService(Training trainee) {
		// TODO Auto-generated method stub
		
	}
	
}
