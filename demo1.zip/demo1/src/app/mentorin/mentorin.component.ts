import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentorin',
  templateUrl: './mentorin.component.html',
  styleUrls: ['./mentorin.component.css']
})
export class MentorinComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
