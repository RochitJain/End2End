import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserinComponent } from './userin/userin.component';
import { UserupComponent } from './userup/userup.component';

import { componentFactoryName } from '@angular/compiler';
import { MainComponent } from './main/main.component';
import { MentorinComponent } from './mentorin/mentorin.component';
import { MentorupComponent } from './mentorup/mentorup.component';
import { AdminComponent } from './admin/admin.component';

@NgModule({
  declarations: [
    AppComponent,
    UserinComponent,
    UserupComponent,
    MainComponent,
    MentorinComponent,
    MentorupComponent,
    AdminComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot([
      {
        path: 'userin',
        component: UserinComponent
      },
      {
        path: 'userup',
        component: UserupComponent
      },

      {
        path: '',
        component: MainComponent
      },
      {
        path: 'mentorin',
        component: MentorinComponent
      },
      {
        path: 'mentorup',
        component: AppComponent
      },
      {
        path: 'admin',
        component: AdminComponent
      },    //   {
      //     path: '',
      //   pathMatch: 'full',
      //   redirectTo: 'userup'

      // }
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
