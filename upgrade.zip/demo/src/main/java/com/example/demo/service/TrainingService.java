package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Training;
import com.example.demo.repository.TrainingRepo;



@Service
public class TrainingService {

	@Autowired
	TrainingRepo train;
	public List<Training>getAllTrain(){
		List<Training> trainn=train.findAll();
		return trainn;
	}
	
}
